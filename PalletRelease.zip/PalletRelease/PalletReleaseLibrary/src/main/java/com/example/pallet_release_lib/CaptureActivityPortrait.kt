package com.example.pallet_release_lib

class CaptureActivityPortrait {
}