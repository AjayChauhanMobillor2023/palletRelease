package com.example.pallet_release_lib

class AppConstants {

        companion object{
                const val EMPTY_PALLET_MODULE_HEADER = "Pallet Release"

                const val industrialDeviceCipherLabNewland = "Newland"
                const val industrialDeviceCipherLabHoneywell = "Honeywell"
                const val industrialDeviceCipherLab = "CipherLab"
                const val industrialDevice="CipherLab"
        }
}